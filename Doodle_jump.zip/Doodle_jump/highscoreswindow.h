#ifndef HIGHSCORESWINDOW_H
#define HIGHSCORESWINDOW_H

#include <QDialog>
#include <QTableWidget>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QPair>
#include <QList>

class HighScoresWindow : public QDialog
{
    Q_OBJECT
public:
    QList<QPair<QString, int>> getScoreMarkers() const;
    explicit HighScoresWindow(QWidget *parent = nullptr);
    void addScore(const QString &nick, int score);
    void resetScores();

private:
    QTableWidget *table;
    QJsonArray scoresArray;
    void loadScores();
    void saveScores();
    void updateTable();
};

#endif // HIGHSCORESWINDOW_H
