#ifndef HIGHSCORESWINDOW_H
#define HIGHSCORESWINDOW_H

#include <QDialog>
#include <QTableWidget>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

class HighScoresWindow : public QDialog
{
    Q_OBJECT
public:
    explicit HighScoresWindow(QWidget *parent = nullptr);
    void addScore(const QString &nick, int score);
    void resetScores();

private:
    QTableWidget *table;
    void loadScores();
    void saveScores(const QJsonArray &scores);
};

#endif // HIGHSCORESWINDOW_H
