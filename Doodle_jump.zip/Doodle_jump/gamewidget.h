#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QPixmap>
#include <QList>
#include <QWidget>
#include <QTimer>
#include <QPixmap>
#include <QList>
#include <QPainter>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QDateTime>
#include <QKeyEvent>
#include <QPair>

class GameWidget : public QWidget
{
    Q_OBJECT
public:
    explicit GameWidget(QWidget *parent = nullptr);
    void startGame();
    void stopGame();
    void resetGame();
    void setBackground(const QString &path);
    void setCharacter(const QString &path);
    void setWallMode(int wallMode);
    void setScoreMarkers(const QList<QPair<QString, int>>& markers);

signals:
    void gameOver(int score);
    void backToMenuRequested();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void keyReleaseEvent(QKeyEvent *event) override;
    void focusInEvent(QFocusEvent *event) override;

private:
    struct Platform {
        int x, y;
        int type; // 0-normal, 1-fragile, 2-moving, 3-bonus, 4-spring, 5-trampoline, 6-blackHole
        int moveDirection;
        int fragileState = -1;
        bool hasSpring = false;
        bool hasTrampoline = false;
        bool springCompressed = false;
        bool trampolineStretched = false;
        qint64 lastAnimationTime = 0;
    };

    struct UFO {
        int x, y;
        int speed;
        bool hasLight;
    };

    QTimer *gameTimer;
    QPixmap background;
    QPixmap doodle;

    QPixmap gameTiles;
    QPixmap character;  // Или doodle, если используете это имя

    QList<Platform> platforms;
    QList<UFO> ufos;
    int playerX, playerY;
    float velocityY;
    bool moveLeft, moveRight;
    int score;
    bool gameActive;
    float difficulty;
    int wallMode; // 0 - Teleport, 1 - Block
    QString playerName;
    QList<QPair<QString, int>> scoreMarkers;
    bool showScoreMarkers = true;

    void initGame();
    void updateGame();
    void generatePlatform();
    void generateUFO();
    void checkCollisions();
    void checkUFOCollisions();
    void updateDifficulty();
    void drawPlatforms(QPainter &painter);
    void drawUFOs(QPainter &painter);
    void drawScore(QPainter &painter);
    void drawScoreMarkers(QPainter &painter);

    const int BASE_PLATFORM_COUNT = 20;
    int platformCount;
    const int MIN_PLATFORM_GAP = 100;
    const int MAX_PLATFORM_GAP = 200;
    const int JUMP_HEIGHT = -15;
    const float MOVE_SPEED = 3.5f;
    const float GRAVITY = 0.3f;
    const float MOVING_PLATFORM_SPEED = 1.5f;
    const float BONUS_MULTIPLIER = 2.0f;
    const float SPRING_JUMP_HEIGHT = -25.0f;
    const float TRAMPOLINE_JUMP_HEIGHT = -35.0f;

    const int ufoWidth = 161;
    const int ufoHeight = 247;

    // Sprite rectangles
    const QRect normalPlatformRect = QRect(2, 2, 114, 30);
    const QRect movingPlatformRect = QRect(2, 36, 114, 30);
    const QList<QRect> fragilePlatformRects = {
        QRect(2, 145, 120, 30),
        QRect(2, 181, 121, 40),
        QRect(4, 231, 113, 55),
        QRect(3, 297, 116, 64)
    };
    const QRect springRect = QRect(806, 195, 36, 26);
    const QRect springStretchedRect = QRect(806, 229, 36, 55);
    const QRect trampolineRect = QRect(375, 195, 74, 29);
    const QRect trampolineStretchedRect = QRect(297, 190, 74, 35);
    const QRect blackHoleRect = QRect(454, 100, 147, 133);
    const QRect ufoWithLightRect = QRect(857, 163, 161, 247);
    const QRect ufoWithoutLightRect = QRect(861, 413, 161, 247);
};

#endif // GAMEWIDGET_H
