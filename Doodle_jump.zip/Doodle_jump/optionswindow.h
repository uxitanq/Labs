#ifndef OPTIONSWINDOW_H
#define OPTIONSWINDOW_H

#include <QDialog>

class OptionsWindow : public QDialog
{
    Q_OBJECT
public:
    explicit OptionsWindow(QWidget *parent = nullptr);

signals:
    void backgroundChanged(const QString &path);
    void characterChanged(const QString &path);
    void wallModeChanged(int wallMode);
    void scoresResetRequested();
    void scoreMarkersChanged();

private slots:
    void onBackgroundClicked();
    void onCharacterClicked();
    void onWallModeChanged(int index);
    void onResetScoresClicked();
    void onScoreMarkersChanged();

private:
    void setupUi();
    bool showScoreMarkers = true;
};

#endif // OPTIONSWINDOW_H
