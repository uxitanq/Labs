#ifndef DOODLE_JUMP_H
#define DOODLE_JUMP_H

#include <QMainWindow>
#include "gamewidget.h"
#include "highscoreswindow.h"
#include "optionswindow.h"

class DoodleJump : public QMainWindow
{
    Q_OBJECT
public:
    explicit DoodleJump(QWidget *parent = nullptr);

private slots:
    void showGame();
    void showMenu();
    void handleGameOver(int score);
    void updateScoreMarkers();

private:
    GameWidget *gameWidget;
    QWidget *menuWidget;
    HighScoresWindow *highScoresWindow;
    OptionsWindow *optionsWindow;

    void setupMainMenu();
    void setupGameWidget();
    void setupConnections();
};

#endif // DOODLE_JUMP_H
