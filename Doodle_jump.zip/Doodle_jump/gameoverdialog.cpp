#include "gameoverdialog.h"
#include "doodle_jump.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>

GameOverDialog::GameOverDialog(int score, QWidget *parent) : QDialog(parent)
{
    setWindowTitle("Game Over");
    setFixedSize(300, 150);

    QVBoxLayout *layout = new QVBoxLayout(this);

    QLabel *label = new QLabel(QString("Your score: %1").arg(score));
    label->setAlignment(Qt::AlignCenter);
    layout->addWidget(label);

    nameEdit = new QLineEdit(this);
    nameEdit->setPlaceholderText("Enter your name");
    layout->addWidget(nameEdit);

    QPushButton *saveBtn = new QPushButton("Save", this);
    QPushButton *skipBtn = new QPushButton("Skip", this);

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(saveBtn);
    btnLayout->addWidget(skipBtn);

    connect(saveBtn, &QPushButton::clicked, this, [this](){
        QDialog::accept();
    });
    connect(skipBtn, &QPushButton::clicked, this, [this](){
        QDialog::reject();
    });

    setWindowTitle("Game Over - Score: " + QString::number(score));
    setModal(true);
    connect(nameEdit, &QLineEdit::returnPressed,
            saveBtn, &QPushButton::click);

    layout->addLayout(btnLayout);
    nameEdit->setFocus();
}

QString GameOverDialog::getPlayerName() const
{
    return nameEdit->text().trimmed();
}
