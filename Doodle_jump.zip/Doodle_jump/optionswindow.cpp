#include "optionswindow.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QGroupBox>
#include <QComboBox>
#include <QFileDialog>
#include <QMessageBox>
#include <QCheckBox>

OptionsWindow::OptionsWindow(QWidget *parent) : QDialog(parent)
{
    setWindowTitle("Options");
    setFixedSize(400, 300);
    setupUi();
}

void OptionsWindow::setupUi()
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    QGroupBox *graphicsGroup = new QGroupBox("Graphics", this);
    QVBoxLayout *graphicsLayout = new QVBoxLayout(graphicsGroup);

    QPushButton *bgButton = new QPushButton("Select Background", this);
    connect(bgButton, &QPushButton::clicked, this, &OptionsWindow::onBackgroundClicked);

    QPushButton *charButton = new QPushButton("Select Character", this);
    connect(charButton, &QPushButton::clicked, this, &OptionsWindow::onCharacterClicked);

    graphicsLayout->addWidget(bgButton);
    graphicsLayout->addWidget(charButton);

    QGroupBox *gameGroup = new QGroupBox("Gameplay", this);
    QVBoxLayout *gameLayout = new QVBoxLayout(gameGroup);

    QComboBox *wallCombo = new QComboBox(this);
    wallCombo->addItem("Teleport through walls");
    wallCombo->addItem("Block at walls");
    connect(wallCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &OptionsWindow::onWallModeChanged);

    QPushButton *resetBtn = new QPushButton("Reset High Scores", this);
    connect(resetBtn, &QPushButton::clicked, this, &OptionsWindow::onResetScoresClicked);

    gameLayout->addWidget(wallCombo);
    gameLayout->addWidget(resetBtn);

    QCheckBox *scoreMarkersCheckbox = new QCheckBox("Show Score Markers", this);
    scoreMarkersCheckbox->setChecked(showScoreMarkers);
    connect(scoreMarkersCheckbox, &QCheckBox::stateChanged, this, &OptionsWindow::onScoreMarkersChanged);
    gameLayout->addWidget(scoreMarkersCheckbox);

    QPushButton *okBtn = new QPushButton("OK", this);
    connect(okBtn, &QPushButton::clicked, this, &QDialog::accept);

    layout->addWidget(graphicsGroup);
    layout->addWidget(gameGroup);
    layout->addStretch();
    layout->addWidget(okBtn, 0, Qt::AlignRight);
}

void OptionsWindow::onBackgroundClicked()
{
    QString path = QFileDialog::getOpenFileName(this, "Select Background",
                                                "", "Images (*.png *.jpg *.bmp)");
    if (!path.isEmpty()) {
        emit backgroundChanged(path);
    }
}

void OptionsWindow::onCharacterClicked()
{
    QString path = QFileDialog::getOpenFileName(this, "Select Character",
                                                "", "Images (*.png *.jpg *.bmp)");
    if (!path.isEmpty()) {
        emit characterChanged(path);
    }
}

void OptionsWindow::onWallModeChanged(int index)
{
    emit wallModeChanged(index);
}

void OptionsWindow::onResetScoresClicked()
{
    if (QMessageBox::question(this, "Reset Scores",
                              "Are you sure you want to reset all high scores?",
                              QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes) {
        emit scoresResetRequested();
    }
}

void OptionsWindow::onScoreMarkersChanged()
{
    emit scoreMarkersChanged();
}
