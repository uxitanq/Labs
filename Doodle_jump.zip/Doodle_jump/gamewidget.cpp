#include "gamewidget.h"
#include <QPainter>
#include <QKeyEvent>
#include <QDebug>
#include <QRandomGenerator>
#include <QMessageBox>
#include <algorithm>
#include <cmath>

GameWidget::GameWidget(QWidget *parent) : QWidget(parent)
{
    setFixedSize(600, 800);
    setFocusPolicy(Qt::StrongFocus);

    gameTiles.load("images/game-tiles@2x.png");
    if (gameTiles.isNull()) {
        qDebug() << "No full.png";
    }
    background.load("images/background.png");
    if (background.isNull()) {
        qDebug() << "Не удалось загрузить background.png";
    }

    doodle.load("images/doodle.png");

    gameTimer = new QTimer(this);
    connect(gameTimer, &QTimer::timeout, this, &GameWidget::updateGame);

    initGame();
}

void GameWidget::startGame()
{
    initGame();
    gameActive = true;
    gameTimer->start(16);
    setFocus();
}

void GameWidget::stopGame()
{
    gameTimer->stop();
    gameActive = false;

}

void GameWidget::resetGame()
{
    initGame();
}

/**void GameWidget::generatePlatform() {
    Platform p;
    const int platformWidth = 70;
    const int platformHeight = 14;

    if (platforms.isEmpty()) {
        p.x = width()/2 - platformWidth/2;
        p.y = height() - 100;
    } else {
        const Platform& last = platforms.last();

        p.y = last.y - QRandomGenerator::global()->bounded(MIN_PLATFORM_GAP, MAX_PLATFORM_GAP);

        p.y = qMax(p.y, 50);

        int maxHorizontal = 120; // Макс. горизонтальное расстояние прыжка
        int minX = qMax(20, last.x - maxHorizontal);
        int maxX = qMin(width() - platformWidth - 20, last.x + maxHorizontal);
        p.x = QRandomGenerator::global()->bounded(minX, maxX);
    }

    // Тип платформы: 0 - normal, 1 - fragile, 2 - moving, 3 - bonus, 4 - spring, 5 - trampoline, 6 - blackHole
    int platformTypeRand = QRandomGenerator::global()->bounded(100);
    if (platformTypeRand < (10 + difficulty * 10)) {
        p.type = 1;
        p.fragileState = 0;
    } else if (platformTypeRand < (20 + difficulty * 10)) {
        p.type = 2;
        p.moveDirection = QRandomGenerator::global()->bounded(2) ? 1 : -1;
    } else if (platformTypeRand < (25 + difficulty * 5)) {
        p.type = 3;
    } else if (platformTypeRand < (30 + difficulty * 5)) {
        p.type = 4;
    } else if (platformTypeRand < (35 + difficulty * 5)) {
        p.type = 5;
    } else if (platformTypeRand < (40 + difficulty * 5)) {
        p.type = 6;
    }
    else {
        p.type = 0;
    }
    if (QRandomGenerator::global()->bounded(1000) < 1) {
        generateUFO();
    }

    platforms.append(p);

    std::sort(platforms.begin(), platforms.end(),
              [](const Platform& a, const Platform& b) { return a.y > b.y; });

    while (platforms.size() > platformCount) {
        platforms.removeLast();
    }
}**/

void GameWidget::generatePlatform() {
    Platform p;
    const int platformWidth = 70;
    const int platformHeight = 14;

    if (platforms.isEmpty()) {
        p.x = width()/2 - platformWidth/2;
        p.y = height() - 100;
    } else {
        bool validPosition = false;
        int attempts = 0;
        do {
            const Platform& last = platforms.last();

            p.y = last.y - QRandomGenerator::global()->bounded(MIN_PLATFORM_GAP, MAX_PLATFORM_GAP);

            p.y = qMax(p.y, 50);

            int maxHorizontal = 120;
            int minX = qMax(20, last.x - maxHorizontal);
            int maxX = qMin(width() - platformWidth - 20, last.x + maxHorizontal);
            p.x = QRandomGenerator::global()->bounded(minX, maxX);

            validPosition = true;
            for (const Platform& existingPlatform : platforms) {
                if (&existingPlatform == &p) continue;
                if (abs(p.x - existingPlatform.x) < platformWidth && abs(p.y - existingPlatform.y) < platformHeight) {
                    validPosition = false;
                    break;
                }
            }
            attempts++;
            if (attempts > 100) {
                qDebug() << "Превышено количество попыток генерации платформы";
                break;
            }
        } while (!validPosition);
    }

    // Тип платформы: 0 - normal, 1 - fragile, 2 - moving, 3 - bonus, 4 - spring, 5 - trampoline, 6 - blackHole
    int platformTypeRand = QRandomGenerator::global()->bounded(100);
    if (platformTypeRand < (10 + difficulty * 10)) {
        p.type = 1;
        p.fragileState = 0;
    } else if (platformTypeRand < (20 + difficulty * 10)) {
        p.type = 2;
        p.moveDirection = QRandomGenerator::global()->bounded(2) ? 1 : -1;
    } else if (platformTypeRand < (25 + difficulty * 5)) {
        p.type = 3;
    } else if (platformTypeRand < (30 + difficulty * 5)) {
        p.type = 4;
    } else if (platformTypeRand < (35 + difficulty * 5)) {
        p.type = 5;
    } else if (platformTypeRand < (40 + difficulty * 5)) {
        p.type = 6;
    }
    else {
        p.type = 0;
    }

    platforms.append(p);

    std::sort(platforms.begin(), platforms.end(),
              [](const Platform& a, const Platform& b) { return a.y > b.y; });

    while (platforms.size() > platformCount) {
        platforms.removeLast();
    }
}


/**void GameWidget::generateUFO() {
    UFO ufo;
    ufo.x = QRandomGenerator::global()->bounded(0, width() - ufoWidth);
    ufo.y = -ufoHeight; // Начинаем за экраном
    ufo.speed = QRandomGenerator::global()->bounded(1, 3);
    ufo.hasLight = QRandomGenerator::global()->bounded(2); // 0 или 1 (свет или без)
    ufos.append(ufo);
}**/

void GameWidget::updateGame() {
    if (!gameActive) return;

    // Движение игрока
    if (moveLeft) playerX -= MOVE_SPEED;
    if (moveRight) playerX += MOVE_SPEED;

    // Обработка стен
    if (wallMode == 0) { // Teleport
        if (playerX < -50) playerX = width();
        if (playerX > width()) playerX = -50;
    } else { // Block
        playerX = qBound(0, playerX, width()-50);
    }

    velocityY += GRAVITY;
    playerY += velocityY;

    for (Platform &p : platforms) {
        if (p.type == 2) {
            p.x += p.moveDirection * MOVING_PLATFORM_SPEED;
            if (p.x < 0 || p.x > width()-70) {
                p.moveDirection *= -1;
            }
        }
    }

    /**for (UFO &ufo : ufos) {
        ufo.y += ufo.speed;
    }**/

    if (playerY < height()/3) {
        float dy = height()/3 - playerY;
        playerY = height()/3;
        score += dy * 0.1f;

        for (Platform &p : platforms) {
            p.y += dy;
        }
        for (UFO &ufo : ufos) {
            ufo.y += dy;
        }

        platforms.erase(std::remove_if(platforms.begin(), platforms.end(),
                                       [this](const Platform& p) { return p.y > height(); }), platforms.end());

        ufos.erase(std::remove_if(ufos.begin(), ufos.end(),
                                  [this](const UFO& ufo) { return ufo.y > height(); }), ufos.end());

        while (platforms.size() < platformCount) {
            generatePlatform();
        }

        /**if (QRandomGenerator::global()->bounded(100) < 5) { // 5% шанс
            generateUFO();
        }**/

        updateDifficulty();
    }

    if (playerY > height() + 100) {
        stopGame();
        emit gameOver(score);
        return;
    }

    checkCollisions();
    //checkUFOCollisions();
    update();
}

void GameWidget::checkCollisions() {
    for (Platform &p : platforms) {
        bool onPlatform = (playerY + 50 >= p.y) &&
                          (playerY + 50 <= p.y + 14) &&
                          (playerX + 40 > p.x) &&
                          (playerX < p.x + 70);

        if (onPlatform && velocityY > 0) {
            switch (p.type) {
            case 1:
                if (p.fragileState < fragilePlatformRects.size() - 1) {
                    p.fragileState++;
                } else {
                    p.y = height() + 100;
                }
                break;
            case 3:
                score *= BONUS_MULTIPLIER;
                p.y = height() + 100;
                break;
            case 4:
                velocityY = SPRING_JUMP_HEIGHT;
                playerY = p.y - 50;
                break;
            case 5:
                velocityY = TRAMPOLINE_JUMP_HEIGHT;
                playerY = p.y - 50;
                break;
            case 6:
                stopGame();
                emit gameOver(score);
                return;
            default:
                velocityY = JUMP_HEIGHT;
                playerY = p.y - 50;
                break;
            }
            break;
        }
    }
}

/**void GameWidget::checkUFOCollisions() {
    for (const UFO &ufo : ufos) {
        bool collision = (playerX > ufo.x) &&
                         (playerX < ufo.x + ufoWidth) &&
                         (playerY > ufo.y) &&
                         (playerY < ufo.y + ufoHeight) && ufo.hasLight;

        if (collision) {
            stopGame();
            emit gameOver(score);
            return;
        }
    }
}**/

void GameWidget::initGame() {
    playerX = width()/2 - 25;
    playerY = height()/2;
    velocityY = 0;
    moveLeft = moveRight = false;
    score = 0;
    difficulty = 0;
    platforms.clear();
    ufos.clear();
    platformCount = BASE_PLATFORM_COUNT;

    for (int i = 1; i < platformCount; i++) { // Начинаем с 1, а не с 0
        generatePlatform();
    }

    Platform initialPlatform;
    initialPlatform.x = playerX - 10;
    initialPlatform.y = playerY + 100;
    initialPlatform.type = 0;
    platforms.append(initialPlatform);

    //bool hasPlatform = false;
    //for (Platform &p : platforms) {
    //    if (p.y >= playerY && playerX + 50 > p.x && playerX < p.x + 70) {
    //        hasPlatform = true;
    //        break;
    //    }
    //}

    //if (!hasPlatform) {
    //    Platform p;
    //    p.x = playerX - 10;
    //    p.y = playerY + 100;
    //    p.type = 0;
    //    platforms.append(p);
    //}

    std::sort(platforms.begin(), platforms.end(),
              [](const Platform& a, const Platform& b) { return a.y > b.y; });
}



void GameWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);

    painter.drawPixmap(0, 0, width(), height(), background);

    drawPlatforms(painter);

    drawUFOs(painter);

    painter.drawPixmap(playerX, playerY, doodle);

    drawScore(painter);

    if (showScoreMarkers) {
        drawScoreMarkers(painter);
    }
}

void GameWidget::drawPlatforms(QPainter &painter)
{
    for (const Platform &p : platforms) {
        switch (p.type) {
        case 0: painter.drawPixmap(p.x, p.y, gameTiles.copy(normalPlatformRect)); break;
        case 1:
            if (p.fragileState >= 0 && p.fragileState < fragilePlatformRects.size()) {
                painter.drawPixmap(p.x, p.y, gameTiles.copy(fragilePlatformRects[p.fragileState]));
            }
            break;
        case 2: painter.drawPixmap(p.x, p.y, gameTiles.copy(movingPlatformRect)); break;
        case 3: painter.drawPixmap(p.x, p.y, gameTiles.copy(normalPlatformRect)); break;
        case 4: painter.drawPixmap(p.x + 15, p.y - 15, gameTiles.copy(springRect)); break;
        case 5: painter.drawPixmap(p.x, p.y, gameTiles.copy(trampolineRect)); break;
        case 6: painter.drawPixmap(p.x, p.y, gameTiles.copy(blackHoleRect)); break;
        }
    }
}

void GameWidget::drawUFOs(QPainter &painter) {
    for (const UFO &ufo : ufos) {
        if (ufo.hasLight) {
            painter.drawPixmap(ufo.x, ufo.y, gameTiles.copy(ufoWithLightRect));
        } else {
            painter.drawPixmap(ufo.x, ufo.y, gameTiles.copy(ufoWithoutLightRect));
        }
    }
}

void GameWidget::drawScore(QPainter &painter)
{
    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial", 24, QFont::Bold));
    painter.drawText(20, 40, QString("Score: %1").arg(score));
}

void GameWidget::drawScoreMarkers(QPainter &painter)
{
    painter.setPen(Qt::red);
    painter.setFont(QFont("Arial", 14));

    for (const auto& marker : scoreMarkers) {
        int yPos = height() - marker.second;
        painter.drawLine(0, yPos, width(), yPos);
        painter.drawText(10, yPos - 5, marker.first + " " + QString::number(marker.second));
    }
}

void GameWidget::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Left:
    case Qt::Key_A:
        moveLeft = true;
        break;
    case Qt::Key_Right:
    case Qt::Key_D:
        moveRight = true;
        break;
    case Qt::Key_Escape:
        stopGame();
        emit backToMenuRequested();
        break;
    default:
        QWidget::keyPressEvent(event);
    }
}

void GameWidget::keyReleaseEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Left:
    case Qt::Key_A:
        moveLeft = false;
        break;
    case Qt::Key_Right:
    case Qt::Key_D:
        moveRight = false;
        break;
    default:
        QWidget::keyReleaseEvent(event);
    }
}

void GameWidget::focusInEvent(QFocusEvent *event)
{
    Q_UNUSED(event);
    setFocus();
}

void GameWidget::setBackground(const QString &path)
{
    if (background.load(path)) {
        update();
    }
}

void GameWidget::setCharacter(const QString &path)
{
    if (doodle.load(path)) {
        update();
    }
}

void GameWidget::setWallMode(int mode)
{
    wallMode = mode;
}

void GameWidget::setScoreMarkers(const QList<QPair<QString, int>>& markers) {
    scoreMarkers = markers;
    update();
}

void GameWidget::updateDifficulty() {
    difficulty = qMin(1.0f, score / 5000.0f);
    platformCount = BASE_PLATFORM_COUNT * (1 - difficulty);
}
