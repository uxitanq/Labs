#include "doodle_jump.h"
#include "highscoreswindow.h"
#include "optionswindow.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QMessageBox>
#include <QApplication>

#include "gameoverdialog.h"

DoodleJump::DoodleJump(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle("Doodle Jump");
    setFixedSize(600, 800);

    setupMainMenu();
    setupGameWidget();
    setupConnections();

    showMenu();
}

void DoodleJump::setupMainMenu()
{
    menuWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(menuWidget);

    QString buttonStyle = "QPushButton {"
                          "background-color: #9370DB;"
                          "border: 2px solid #4B0082;"
                          "color: white;"
                          "padding: 15px;"
                          "border-radius: 10px;"
                          "font-size: 18px;"
                          "margin: 10px;"
                          "}"
                          "QPushButton:hover {"
                          "background-color: #BA55D3;"
                          "}";

    QPushButton *playBtn = new QPushButton("Play", menuWidget);
    playBtn->setStyleSheet(buttonStyle);
    connect(playBtn, &QPushButton::clicked, this, &DoodleJump::showGame);

    QPushButton *highScoresBtn = new QPushButton("High Scores", menuWidget);
    highScoresBtn->setStyleSheet(buttonStyle);
    connect(highScoresBtn, &QPushButton::clicked, [this]() {
        highScoresWindow->exec();
    });

    QPushButton *optionsBtn = new QPushButton("Options", menuWidget);
    optionsBtn->setStyleSheet(buttonStyle);
    connect(optionsBtn, &QPushButton::clicked, [this]() {
        optionsWindow->exec();
    });

    QPushButton *exitBtn = new QPushButton("Exit", menuWidget);
    exitBtn->setStyleSheet(buttonStyle);
    connect(exitBtn, &QPushButton::clicked, this, &QMainWindow::close);

    layout->addStretch();
    layout->addWidget(playBtn);
    layout->addWidget(highScoresBtn);
    layout->addWidget(optionsBtn);
    layout->addWidget(exitBtn);
    layout->addStretch();

    menuWidget->setLayout(layout);
}

void DoodleJump::setupGameWidget()
{
    gameWidget = new GameWidget(this);
    highScoresWindow = new HighScoresWindow(this);
    optionsWindow = new OptionsWindow(this);
}

void DoodleJump::setupConnections()
{
    connect(gameWidget, &GameWidget::backToMenuRequested, this, &DoodleJump::showMenu);
    connect(gameWidget, &GameWidget::gameOver, this, &DoodleJump::handleGameOver);
    connect(optionsWindow, &OptionsWindow::backgroundChanged, gameWidget, &GameWidget::setBackground);
    connect(optionsWindow, &OptionsWindow::characterChanged, gameWidget, &GameWidget::setCharacter);
    connect(optionsWindow, &OptionsWindow::wallModeChanged, gameWidget, &GameWidget::setWallMode);
    connect(optionsWindow, &OptionsWindow::scoresResetRequested, highScoresWindow, &HighScoresWindow::resetScores);
    connect(optionsWindow, &OptionsWindow::scoreMarkersChanged, this, &DoodleJump::updateScoreMarkers);
}

void DoodleJump::handleGameOver(int score) {
    GameOverDialog dialog(score, this);
    int result = dialog.exec();

    if (result == QDialog::Accepted) {
        QString name = dialog.getPlayerName();
        if (!name.isEmpty()) {
            highScoresWindow->addScore(name, score);
        }
    }

    delete gameWidget;
    gameWidget = new GameWidget(this);
    setupConnections();
    showMenu();
}

void DoodleJump::showMenu() {
    if (centralWidget() != menuWidget) {
        setCentralWidget(menuWidget);
        menuWidget->show();
    }
    if (gameWidget) {
        gameWidget->hide();
        gameWidget->stopGame();
    }
}

void DoodleJump::showGame() {
    if (centralWidget() != gameWidget) {
        setCentralWidget(gameWidget);
        gameWidget->show();
        gameWidget->setFocus();
        gameWidget->startGame();
    }
}

void DoodleJump::updateScoreMarkers() {
    gameWidget->setScoreMarkers(highScoresWindow->getScoreMarkers());
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    DoodleJump window;
    window.show();
    return app.exec();
}
