#ifndef GAMEOVERDIALOG_H
#define GAMEOVERDIALOG_H

#include <QDialog>
#include <QLineEdit>

class GameOverDialog : public QDialog {
    Q_OBJECT
public:
    explicit GameOverDialog(int score, QWidget *parent = nullptr);
    QString getPlayerName() const;

signals:
    void returnToMenu();

private:
    QLineEdit *nameEdit;
};

#endif // GAMEOVERDIALOG_H
