#include "highscoreswindow.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QHeaderView>
#include <QJsonDocument>
#include <QMessageBox>
#include <algorithm>
#include <QGroupBox>
#include <QRadioButton>
#include <QSlider>
#include <algorithm>

HighScoresWindow::HighScoresWindow(QWidget *parent) : QDialog(parent) {
    setWindowTitle("High Scores");
    setFixedSize(400, 300);

    table = new QTableWidget(this);
    table->setColumnCount(3);
    table->setHorizontalHeaderLabels({"Nickname", "Score", "Date"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setEditTriggers(QTableWidget::NoEditTriggers);

    QPushButton *closeBtn = new QPushButton("Close", this);
    connect(closeBtn, &QPushButton::clicked, this, &QDialog::close);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(table);
    layout->addWidget(closeBtn);

    loadScores();
}

void HighScoresWindow::addScore(const QString &nick, int score) {
    QJsonObject newScore;
    newScore["nick"] = nick;
    newScore["score"] = score;
    newScore["date"] = QDateTime::currentDateTime().toString("MM.dd.yyyy HH:mm");

    QJsonArray scoresArray;
    QFile file("scores.json");
    if (file.open(QIODevice::ReadOnly)) {
        scoresArray = QJsonDocument::fromJson(file.readAll()).array();
        file.close();
    }

    scoresArray.append(newScore);

    QJsonArray sortedArray;
    std::vector<QJsonValue> values;
    for (const auto &value : scoresArray) {
        values.push_back(value);
    }
    std::sort(values.begin(), values.end(), [](const QJsonValue &a, const QJsonValue &b) {
        return a.toObject()["score"].toInt() > b.toObject()["score"].toInt();
    });
    for (const auto &value : values) {
        sortedArray.append(value);
    }
    if (sortedArray.size() > 10) {
        QJsonArray limitedArray;
        for (int i = 0; i < 10; ++i) {
            limitedArray.append(sortedArray.at(i));
        }
        sortedArray = limitedArray;
    }

    if (file.open(QIODevice::WriteOnly)) {
        file.write(QJsonDocument(sortedArray).toJson());
        file.close();
    }

    loadScores();
}

void HighScoresWindow::resetScores() {
    QFile file("scores.json");
    if (file.open(QIODevice::WriteOnly)) {
        file.write(QJsonDocument(QJsonArray()).toJson());
        file.close();
    }
    loadScores();
}

void HighScoresWindow::loadScores() {
    table->setRowCount(0);
    QFile file("scores.json");
    if (!file.open(QIODevice::ReadOnly)) return;

    QJsonArray scoresArray = QJsonDocument::fromJson(file.readAll()).array();
    for (const QJsonValue &value : scoresArray) {
        QJsonObject obj = value.toObject();
        int row = table->rowCount();
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(obj["nick"].toString()));
        table->setItem(row, 1, new QTableWidgetItem(QString::number(obj["score"].toInt())));
        table->setItem(row, 2, new QTableWidgetItem(obj["date"].toString()));
    }
}

void HighScoresWindow::saveScores()
{
    QFile file("highscores.json");
    if (file.open(QIODevice::WriteOnly)) {
        file.write(QJsonDocument(scoresArray).toJson());
        file.close();
    }
}

void HighScoresWindow::updateTable()
{
    table->setRowCount(0);
    for (int i = 0; i < scoresArray.size(); ++i) {
        QJsonObject obj = scoresArray[i].toObject();
        int row = table->rowCount();
        table->insertRow(row);

        table->setItem(row, 0, new QTableWidgetItem(QString::number(row + 1)));
        table->setItem(row, 1, new QTableWidgetItem(obj["name"].toString()));
        table->setItem(row, 2, new QTableWidgetItem(QString::number(obj["score"].toInt())));
    }
}

QList<QPair<QString, int>> HighScoresWindow::getScoreMarkers() const {
    QList<QPair<QString, int>> markers;
    for (int i = 0; i < table->rowCount(); ++i) {
        markers.append({table->item(i, 0)->text(),
                        table->item(i, 1)->text().toInt()});
    }
    return markers;
}
